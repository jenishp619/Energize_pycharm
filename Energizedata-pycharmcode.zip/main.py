
import pandas as pd
from influxdb import client as influxdb
# client = InfluxDBClient(host='localhost', port=8086)
# client.switch_database('databse_name')

db = influxdb.InfluxDBClient("10.217.41.144", 8086, "homeassistant", "admin", "homeassistant")
file_path = r'sensor.csv'

csvReader = pd.read_csv(file_path)

# print(csvReader.shape)
# print(csvReader.columns)

for row_index, row in csvReader.iterrows() :
    print(row_index,row)
    tags = row[2]
    #fieldvalue = row[2]
    # json_body = [
    #     {
    #         "measurement": "newdata",
    #     "tags": {
    #     "Tag_name1": tags
    #              },
    #         "fields": {
    #                     "Field1": row[2],
    #                     "Field2": row[3],
    #                     "Field3": row[4]
    #                     }
    #     }
    # ]
    json_body = [
        {
            "measurement": "tagwithenergize",
            "tags": {
                    "type": tags
                            },
                "fields": {
                "sensor": row[0],
                "sensorboxid": row[1],
                #"type": row[2],
                "unit": row[3],
                "status": row[4],
                "roomid": row[5],
                "counter": row[9],
                "scalingfactor": row[7]
            }
        }
    ]
    db.write_points(json_body)